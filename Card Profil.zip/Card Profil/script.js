const darkModeButton = document.getElementById("darkModeButton");

darkModeButton.addEventListener("click", function () {

    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {
        darkModeButton.textContent = "☀️ Mode Terang";
    } else {
        darkModeButton.textContent = "🌙 Mode Gelap";
    }

});